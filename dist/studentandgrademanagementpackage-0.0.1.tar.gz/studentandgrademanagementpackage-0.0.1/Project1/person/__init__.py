from .person import Person
from .student import Student
from .teacher import Teacher

__all__ = ["Person", "Student", "Teacher"]